#include "chronometry.h"

// 1. 재귀 호출 사용.

int sum2(int n)
{
	if (n == 1) return 1;
	return n + sum2(n - 1);
}


// 2. 꼬리 재귀(Tale Recursion)

int sumTail(int n, int result)
{
	if (n == 1) return result;
	return sumTail(n - 1, result + n);
}

int sum3(int n)
{
	return sumTail(n, 1);
}



int main()
{
	int cnt = 10000;
	int ret1 = sum2(cnt);
	int ret2 = sum3(cnt);
}
