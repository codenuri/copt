#include "chronometry.h"

#define LOOPCOUNT 100000

// 일반 함수
int add1(int a, int b)
{
	return a + b;
}

// 매크로 함수
#define add2(x, y)   ((x) + (y))

void bad()
{
	int n1 = 0;
	int x = 10, y = 20;

	for (int i = 0; i < LOOPCOUNT; i++)
	{
		n1 = add1(x, y);
	}
	printf("bad : %d\n", n1);
}

void good()
{
	int n1 = 0;
	int x = 10, y = 20;

	for (int i = 0; i < LOOPCOUNT; i++)
	{
		n1 = add2(x, y);
	}
	printf("good : %d\n", n1);
}

int main()
{
	int n1 = 0, n2 = 0;
	int x = 10, y = 20;

	CHRONOMETRY(bad);
	CHRONOMETRY(good);
}
