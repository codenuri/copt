// 51 page
#include <stdio.h>

int main()
{
	int x[3] = { 1,2,3 };

	int (*p)[3] = &x; 
						   
}
