#include <stdio.h>

#ifdef _DEBUG 
#define dprint(x) printf(x)
#else 
#define dprint(x) 
#endif

int main()
{
	int n = 0;

	dprint("debug message\n");
}