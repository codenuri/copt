#include <stdio.h>

#define SQUARE(x) x * x

int main()
{
	// 매크로 함수의 장점
	// 1. 빠르다
	// 2. Generic!
	int    r1 = SQUARE(3);		
	double r2 = SQUARE(3.4);


	// 단점 : 버그가 많다.
	int n = 3;

	int ret = SQUARE(n+1);


	printf("%d\n", ret);
}

