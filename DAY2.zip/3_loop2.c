#include "chronometry.h"

// 루프에서는 포인터를 "dereferencing" 사용하지 말라.

// [first ~ last] 구간의 합을 s 에 담는 함수. 

void bad(int first, int last, int* s)
{
	for (int i = first; i <= last; i++)
	{
		*s += i;
	}
}

void good(int first, int last, int* s)
{	
	int local = *s;

	for (int i = first; i <= last; i++)
	{
		local += i;  
	}
	*s = local;
}

const int count = 1000000;

void ex1()
{
	int s = 0;
	bad(1, count, &s);
}

void ex2()
{
	int s = 0;
	good(1, count, &s);
}

int main()
{
	CHRONOMETRY(ex1);
	CHRONOMETRY(ex2);
}
