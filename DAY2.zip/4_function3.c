// 107 page
// call by value vs call by pointer

struct big
{
	int arr[1000];
	char str[1000];
};

void bad(struct big arg)	
{
}

void good(const struct big* arg)	
{
}

int main()
{
	struct big b = { 0 };

	bad(b);
	good(&b);
}

