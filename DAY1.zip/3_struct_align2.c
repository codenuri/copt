#include "chronometry.h"

const unsigned long long count = 100000000;

typedef struct _packet1
{
	char cmd;
	int data;
} PACKET1;

#pragma pack(1)
typedef struct _packet2
{
	char cmd;
	int data;
} PACKET2;


PACKET1 packet1;
PACKET2 packet2;

void ex1()
{
	for (unsigned long long i = 0; i <= count; i++)
	{
		packet1.data = i;
	}
}

void ex2()
{
	for (unsigned long long i = 0; i <= count; i++)
	{
		packet2.data = i;
	}
}

int main()
{

	CHRONOMETRY(ex1);
	CHRONOMETRY(ex2);
}




