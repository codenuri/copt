#include <stdio.h>

__declspec(naked) void f2()
{
	__asm
	{
	}
}

__declspec(naked) void f1()
{
	__asm
	{



		mov   eax, 10
		ret
	}
}

int main()
{
	int ret;

	ret = f1();

	printf("main : %d\n", ret);
}