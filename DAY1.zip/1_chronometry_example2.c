#include "chronometry.h"

const unsigned long long count = 10000000;

int add(int a, int b)
{
	return a + b;
}

extern inline int inline_add(int a, int b)
{
	return a + b;
}

void ex1()
{
	for (unsigned long long i = 0; i <= count; i++)
	{
		int ret = add(1, 2);
	}
}

void ex2()
{
	for (unsigned long long i = 0; i <= count; i++)
	{
		int ret = inline_add(1, 2);
	}
}

int main()
{
	// 컴파일러 옵션에 따라 결과가 달라짐.
	CHRONOMETRY(ex1);
	CHRONOMETRY(ex2);	
}
