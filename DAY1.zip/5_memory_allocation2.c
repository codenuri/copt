#include "counter.h"
#include <stdlib.h>

const int count = 10000000;

void use_stack()
{
	int x[1000];
	x[0] = 0;
}

void use_heap()
{
	int* x = (int*)malloc(sizeof(int) * 1000);

	x[0] = 0;

	free(x);
}



void ex1()
{
	for (int i = 0; i < count; i++)
	{
		use_stack();
	}
}

void ex2()
{
	for (int i = 0; i < count; i++)
	{
		use_heap();
	}
}

int main()
{

	CHRONOMETRY(ex1);
	CHRONOMETRY(ex2);
}




