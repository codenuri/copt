// 지역변수의 초기값
int main()
{
	int x = 0x99999999;
	int y = 0x10203040;
	int z = 0x90807060;
}
