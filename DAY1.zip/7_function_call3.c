#include <stdio.h>

void f1()
{
	
}

int main()
{
	f1();
}