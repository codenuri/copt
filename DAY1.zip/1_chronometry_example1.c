#include "chronometry.h"

const unsigned long long count = 100000000;

void ex1()
{
	long long s = 0;

	for (unsigned long long i = 0; i <= count; i++)
		s += i;
}

void ex2()
{
	double s = 0;

	for (double i = 0; i <= count; i++)
		s += i;
}

int main()
{
	ex1();
	ex2();
}
