#include <stdio.h>

int Add(int a, int b)
{
	int c = a + b;

	return c;
}

int main()
{
	int ret;

	ret = Add(1, 2);

	printf("main : %d\n", ret);
}