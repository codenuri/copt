#include <stdio.h>

typedef struct _node
{
	int data;
	struct _node* prev;
	struct _node* next;
} NODE;

NODE* head = 0;

void init_node()
{
}

int main()
{
	init_node();
}