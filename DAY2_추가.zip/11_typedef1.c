typedef int DWORD;
typedef int ARR[2];

int main()
{
	DWORD n;
	ARR   a;
}