#include <stdio.h>

// offset of

typedef struct _point
{
	int x;
	int y;
} POINT;

int main()
{
	POINT* p = 0; 

	p->x = 10;
	Point pt = *p;

	printf("%p\n", &(p->x)); 
	printf("%p\n", &(p->y)); 

}