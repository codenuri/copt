void foo(int a, double d)
{
}

int main()
{
	? p = &foo;
}