int n;
int a[2];
int b[2][2];
int (*p)[2];
void (*f)();

int main()
{
	
}

