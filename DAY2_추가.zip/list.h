// list.h
#pragma once

// 핵심 : 아래 코드는 데이타는 없고, 오직 list 의 노드만 조작 합니다.

typedef struct _node
{
	struct _node* prev;
	struct _node* next;
} NODE;

// 더미 노드 초기화
void init_list(NODE* head)
{
	head->next = head;
	head->prev = head;
}

void __insert_node(NODE* temp, NODE* prev, NODE* next)
{
	temp->prev = prev;
	temp->next = next;

	prev->next = temp;
	next->prev = temp;
}

void insert_front(NODE* node, NODE* head)
{
	__insert_node(node, head, head->next);

}
void insert_back(NODE* node, NODE* head)
{
	__insert_node(node, head->prev, head);
}