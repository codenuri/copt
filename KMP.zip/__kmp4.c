#include <stdio.h>
#include <string.h>

// 핵심 : 중복이 있다면 => 일반적인 경우
// => 아래 알고리즘이 "문자열" 검색의 최고의 알고리즘으로 알려진
//    "KMP" 입니다.

// 핵심 : 접두어와 접미어 의 중복 갯수를 사용 해서 이동 위치를 정하는 점. 

char S[] = "abc abcdab abcdabcdabde"; 
char D[] = "abcdabd";  // => "ab" 라는 문자열이 중복이 있습니다.

// fail 함수 
// fail(6) => [0, 6] 사이에 접두어와 접미어에 중복이 몇개 있는가 ?

// "abcdabd" 문자열의 fail 함수
// fail(0) => "a"			=> 0
// fail(1) => "ab"			=> 0
// fail(2) => "abc"			=> 0
// fail(3) => "abcd"		=> 0
// fail(4) => "abcda"		=> 1
// fail(5) => "abcdab"		=> 2
// fail(6) => "abcdabd"		=> 0

int fail[7] = { 0, 0, 0, 0, 1, 2, 0};

const int s_size = 23; 
const int d_size = 7;  


int main()
{
	int i = 0;
	int j = 0;	
	
	for (i = 0; i < s_size ; i++)
	{	
		while(j > 0 && S[i] != D[j])
				j = fail[j-1];

		if ( S[i] == D[j] )
		{
			// 다 찾은 경우
			if ( j == d_size-1 ) 
				break; 
			else 
				++j;  
		}
	}

	printf("%d\n", i - (d_size - 1));
}


