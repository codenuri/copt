#include <stdio.h>
#include <string.h>

// 2. 문자열에서 "다른문자열 찾기"

char S[] = "abc abcdab abcdabcdabde"; // 23자
char D[] = "abcd"; // 4자

const int s_size = 23; // 문자열 갯수
const int d_size = 4;  

int main()
{
	int i = 0;
	int j = 0;
	int find_flag = 0;

	// 성능 : (s_size - d_size) * d_size 의 2중  루프..
	for (i = 0; i < s_size - d_size ; i++)
	{
		for( j = 0; j < d_size; j++ )
		{
			if (S[i+j] != D[j])
				break;
			else if ( j == d_size-1)
			{
				find_flag = 1;
				break;
			}
		}
		if ( find_flag == 1 ) break;
	}

	printf("%d\n", i);
}


