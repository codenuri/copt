#include <stdio.h>
#include <string.h>

// 핵심 : 검색 하려는 문자열이 중복이 없다면..
// => 실패가 나온 다음 지점부터 다시 검색하면된다.
// => i = 0 일때 j = 3에서 실패하면 i=1이 아닌 i = 4 부터 실행
// => 이중 루프를 단일 루프로!!

char S[] = "abc abcdab abcdabcdabde"; 
char D[] = "abcd"; 

const int s_size = 23; 
const int d_size = 4;  

int main()
{
	int i = 0;
	int j = 0;
	// 핵심 : 이중 루프가 아닌 단일 루프
	for (i = 0; i < s_size ; i++)
	{	
		if ( S[i] == D[j] )
		{
			if ( j == d_size-1 ) 
				break; // 찾은것
			else 
				++j;   // 다음 글자로 이동
		}
		else // 찾이 못했는데.. 다른 글자가 나오면
		{
			j = 0; // i 는 계속 유지 하고 j 만 0으로
		}

	}

	printf("%d\n", i - (d_size - 1));
}


