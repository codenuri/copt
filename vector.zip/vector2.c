#include <stdio.h>

int main()
{
	int cnt = 0;

	printf("학생수를 입력해 주세요 >> ");
	scanf_s("%d", &cnt);

	// 실행시간에 입력된 학생수 만큼 다시 점수를 입력 받아야 합니다.
 	int score[cnt];  // ? 

}